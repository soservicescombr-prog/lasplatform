# netguard/agent/netguard_agent/__init__.py
"""NetGuard Agent — Host vulnerability scanner."""
__version__ = "1.5.3"
